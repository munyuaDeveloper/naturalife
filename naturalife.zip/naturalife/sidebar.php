<?php
	//load the widgets
	do_action( "rtframework_load_widgets"); 		
?>